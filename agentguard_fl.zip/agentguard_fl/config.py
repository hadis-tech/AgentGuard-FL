"""Experiment configuration, device selection and seeding.

Equation, algorithm and table numbers in comments refer to the AgentGuard-FL paper.

Every field of ``Config`` feeds the run ID used to resume experiments, so adding,
removing or renaming a field invalidates existing checkpoints in ``results/``.
"""

from dataclasses import dataclass
from typing import Optional

import numpy as np
import torch


def pick_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    # Apple-silicon GPU. The trainable part of the model is tiny, so CPU is often as fast.
    if getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def set_seed(seed: int) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)


@dataclass(frozen=True)
class Config:
    # ---- Tokenisation / model (Sec. III-C-2, Table I) ----
    n_bins: int = 32                            # B
    backbone_name: str = "prajjwal1/bert-tiny"  # BERT-Tiny: 2 layers, d_model = 128
    backbone_mode: str = "pretrained_frozen"    # | "random_frozen" | "scratch_trainable"
    n_prompts: int = 4                          # m soft prompts

    # ---- Federated setup (Sec. IV-A) ----
    n_clients: int = 10
    n_rounds: int = 30
    local_epochs: int = 5                       # E (Table I)
    lr: float = 1e-3
    batch_size: int = 256
    batch_min: int = 64
    light_plan_min_samples: int = 500           # clients with fewer samples use the light plan (Eq. 24)
    grad_clip_norm: float = 5.0                 # optimiser stability detail; 0 disables
    partition: str = "noniid"                   # "iid" or "noniid" (Dirichlet over classes)
    dirichlet_alpha: float = 0.1
    client_val_frac: float = 0.15

    # ---- Threat model ----
    malicious_frac: float = 0.40                # 4 of 10 clients
    malicious_selection: str = "attack_heavy"   # "attack_heavy" or "random"
    attacker_runs_agent: bool = False
    attacker_forges_telemetry: bool = False
    calfa_norm_projection: bool = True          # Eq. 9
    tau_a: float = 2.0                          # attacker norm budget
    rlfa_mode: str = "attack_to_normal"
    alie_knowledge: str = "partial"             # "partial": attackers estimate mean/std from their own
                                                #   honest updates (Baruch et al. 2019); "full": from benign updates
    alie_z: Optional[float] = None              # None = z from Baruch et al. for (n_clients, n_malicious)
    warmup_rounds: int = 0

    # ---- AgentGuard-FL client (Table I) ----
    gamma_q: float = 0.40
    r_min: float = 0.0
    tau: float = 2.0
    sigma: float = 0.0
    gamma_acc: float = 0.70
    gamma_loss: float = 1.5

    # ---- AgentGuard-FL server (Table I) ----
    kappa_q: float = 8.0
    kappa_l: float = 0.3
    kappa_m: float = 1.0
    lambda_c: float = 0.2
    lambda_R: float = 0.2                       # 0 = no historical reputation
    R0: float = 1.0
    size_power: float = 1.0
    eps: float = 1e-8
    defence_warmup_rounds: int = 0              # rounds of plain size-weighted averaging before trust starts

    # ---- Ablation switches ----
    use_reliability: bool = True                # client: reliability-weighted loss (Eq. 20)
    use_clipping: bool = True                   # client: update clipping (Eq. 29)
    use_trust: bool = True                      # server: all trust weighting
    use_T_lab: bool = True                      # Eq. 34
    use_T_val: bool = True                      # Eq. 35
    use_T_mag: bool = True                      # Eq. 36
    use_T_dir: bool = True                      # Eq. 38

    # ---- Robust aggregators (defender's assumed number of attackers f) ----
    robust_f: Optional[int] = None              # None = round(n_clients * malicious_frac)

    eval_batch: int = 2048
