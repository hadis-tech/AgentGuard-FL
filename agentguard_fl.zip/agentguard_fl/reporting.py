"""Result tables and figures.

Tables use the final round. Metrics are mean +/- std over seeds, with the 95% CI half-width in the
CSV. TP / FN / FP / TN are mean counts over seeds on the fixed test set (N+ attack, N- normal).
``per_run_final.csv`` holds every seed's exact counts and metrics.

Method colours stay fixed across every figure and each method has its own marker, so the figures
read in greyscale.
"""

import os

import numpy as np
import pandas as pd
from scipy.stats import t as _student_t

from .attacks import ATTACK_NAMES
from .metrics import metrics_from_counts

METRICS = ["accuracy", "precision", "recall", "f1", "fpr"]
COUNTS = ["tp", "fn", "fp", "tn"]
GROUP_KEYS = dict(main=["dataset", "attack_name", "rate", "method"],
                  models=["dataset", "attack_name", "rate", "method"],
                  ablation=["dataset", "attack_name", "rate", "method"],
                  backbone=["dataset", "attack_name", "rate", "method"],
                  heterogeneity=["dataset", "setting", "attack_name", "method"],
                  sensitivity=["dataset", "setting"],
                  forged=["dataset", "attack_name", "rate", "method"])


def final_rounds(results: pd.DataFrame, results_dir: str = "results") -> pd.DataFrame:
    """Keep each run's final round, save it, and recompute every metric from its counts."""
    final = results[results["round"] == results.groupby("run_id")["round"].transform("max")].copy()
    final["attack_name"] = final["attack"].map(ATTACK_NAMES)
    final.to_csv(os.path.join(results_dir, "per_run_final.csv"), index=False)

    bad = 0
    for _, r in final.iterrows():
        chk = metrics_from_counts(int(r.tp), int(r.tn), int(r.fp), int(r.fn))
        bad += any(abs(chk[m] - r[m]) > 1e-6 for m in METRICS)
    print(f"Metric/confusion-matrix consistency check: {len(final) - bad}/{len(final)} runs consistent")
    return final


def summarise(df: pd.DataFrame, by: list) -> pd.DataFrame:
    rows = []
    for key, g in df.groupby(by, sort=False):
        row = dict(zip(by, key if isinstance(key, tuple) else (key,)))
        k = len(g)
        for m in METRICS:
            mu, sd = g[m].mean(), g[m].std(ddof=1) if k > 1 else 0.0
            ci = _student_t.ppf(0.975, k - 1) * sd / np.sqrt(k) if k > 1 else 0.0
            row[m] = f"{mu:.2f} ± {sd:.2f}" if k > 1 else f"{mu:.2f}"
            row[f"{m}_ci95"] = round(ci, 2)
        for c in COUNTS:
            row[c.upper()] = round(g[c].mean(), 1) if k > 1 else int(g[c].iloc[0])
        row["N+"] = int(g.tp.iloc[0] + g.fn.iloc[0])
        row["N-"] = int(g.fp.iloc[0] + g.tn.iloc[0])
        row["seeds"] = k
        rows.append(row)
    return pd.DataFrame(rows)


def save_table(df: pd.DataFrame, name: str, results_dir: str = "results") -> None:
    df.to_csv(os.path.join(results_dir, f"{name}.csv"), index=False)
    cols = [c for c in df.columns if not c.endswith("_ci95")]
    try:
        with open(os.path.join(results_dir, f"{name}.tex"), "w", encoding="utf-8") as fh:
            fh.write(df[cols].to_latex(index=False))
    except Exception:
        pass
    print(f"\n=== {name} ===")
    print(df[cols].to_string(index=False))


def save_tables(final: pd.DataFrame, results_dir: str = "results") -> dict:
    tables = {}
    for grp, keys in GROUP_KEYS.items():
        sub = final[final["group"] == grp]
        if grp == "models":   # put the proposed method next to the sequence baselines
            ag = final[(final["group"] == "main") & (final["method"] == "AgentGuard-FL") & (final["attack"] != "none")]
            sub = pd.concat([ag, sub])
        if grp == "forged":
            ag = final[(final["group"] == "main") & (final["method"] == "AgentGuard-FL") & final["attack"].isin(["ca_lfa", "alie"])]
            sub = pd.concat([ag.assign(method="AgentGuard-FL (honest telemetry)"), sub])
        if not sub.empty:
            tables[grp] = summarise(sub, keys)
            save_table(tables[grp], "table_" + ("forged_telemetry" if grp == "forged" else grp), results_dir)

    diag = final[(final["group"] == "main") & (final["defence"] == "agentguard") & (final["attack"] != "none")]
    if not diag.empty:
        print("\nAgentGuard-FL diagnostics (final round): trust, reputation, suspicious-label ratio mu")
        print(diag.groupby(["dataset", "attack_name", "rate"])[["trust_mal", "trust_ben", "rep_mal", "rep_ben",
                                                                "mu_mal", "mu_ben"]].mean().round(3).to_string())
    return tables


def _safe(s) -> str:
    return str(s).replace(" ", "_").replace("/", "_")


def save_figures(results: pd.DataFrame, final: pd.DataFrame, results_dir: str = "results") -> None:
    """Accuracy curves and confusion matrices for the main group."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.ticker import MaxNLocator
    except ImportError:
        print("matplotlib not installed: skipping figures.")
        return

    style = {"AgentGuard-FL": ("#2a78d6", "o", "-"), "FedAvg": ("#eb6834", "s", "--"),
             "Krum": ("#1baf7a", "^", "-."), "Trimmed Mean": ("#eda100", "D", ":")}
    plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                         "grid.alpha": 0.25, "grid.linewidth": 0.6, "lines.linewidth": 2,
                         "font.size": 9, "axes.titlesize": 10})
    main = results[results["group"] == "main"]

    # Accuracy over rounds, one panel per attack and rate, mean over seeds
    for ds_name in main["dataset"].unique():
        d = main[main["dataset"] == ds_name]
        combos = [(a, r) for a in ["ca_lfa", "rlfa", "alie"] for r in sorted(d[d.attack == a]["rate"].unique())]
        if not combos:
            continue
        fig, axes = plt.subplots(1, len(combos), figsize=(3.6 * len(combos), 3.4), sharey=True)
        axes = np.atleast_1d(axes)
        clean = d[(d.attack == "none") & (d.method == "AgentGuard-FL")].groupby("round")["accuracy"].mean()
        for ax, (a, r) in zip(axes, combos):
            for meth, (col, mk, ls) in style.items():
                c = d[(d.attack == a) & (d.rate == r) & (d.method == meth)].groupby("round")["accuracy"].mean()
                if not c.empty:
                    ax.plot(c.index, c.values, color=col, marker=mk, ms=4, markevery=5, ls=ls, label=meth)
            if not clean.empty:
                ax.plot(clean.index, clean.values, color="#8a8a85", lw=1.2, ls=(0, (1, 2)), label="AgentGuard-FL, no attack")
            ax.set_title(f"{ATTACK_NAMES[a]} — rate {int(round(r * 100))}%")
            ax.set_xlabel("Communication round")
            ax.xaxis.set_major_locator(MaxNLocator(integer=True))
        axes[0].set_ylabel("Accuracy (%)")
        handles, labels = axes[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc="lower center", ncol=len(labels), frameon=False, bbox_to_anchor=(0.5, -0.04))
        fig.suptitle(ds_name)
        fig.tight_layout(rect=(0, 0.06, 1, 1))
        fig.savefig(os.path.join(results_dir, f"accuracy_{_safe(ds_name)}.png"), dpi=200, bbox_inches="tight")
        plt.close(fig)

    # Confusion matrices: rows = true class, columns = predicted class; colour = row-normalised rate
    fm = final[final["group"] == "main"]
    for (ds_name, a, r), d in fm.groupby(["dataset", "attack", "rate"], sort=False):
        meths = [m for m in style if m in set(d.method)]
        fig, axes = plt.subplots(1, len(meths), figsize=(2.9 * len(meths), 2.9))
        axes = np.atleast_1d(axes)
        for ax, meth in zip(axes, meths):
            g = d[d.method == meth]
            tp, fn, fp, tn = (g[c].mean() for c in COUNTS)
            M = np.array([[tn, fp], [fn, tp]])
            rates = M / M.sum(axis=1, keepdims=True)
            ax.imshow(rates, cmap="Blues", vmin=0, vmax=1)
            for (i, j), v in np.ndenumerate(M):
                name = [["TN", "FP"], ["FN", "TP"]][i][j]
                ax.text(j, i, f"{name}\n{v:,.0f}\n({100 * rates[i, j]:.1f}%)", ha="center", va="center",
                        fontsize=8, color="white" if rates[i, j] > 0.6 else "#1a1a19")
            ax.set_xticks([0, 1], ["Normal", "Attack"])
            ax.set_yticks([0, 1], ["Normal", "Attack"])
            ax.set_xlabel("Predicted")
            ax.grid(False)
            ax.set_title(meth)
        axes[0].set_ylabel("True")
        seeds_note = f"mean of {d.seed.nunique()} seeds" if d.seed.nunique() > 1 else f"seed {d.seed.iloc[0]}"
        fig.suptitle(f"{ds_name} — {ATTACK_NAMES[a]}" + (f", rate {int(round(r * 100))}%" if a != "none" else "")
                     + f" ({seeds_note})")
        fig.tight_layout()
        fig.savefig(os.path.join(results_dir, f"cm_{_safe(ds_name)}_{a}_{int(round(r * 100))}.png"),
                    dpi=200, bbox_inches="tight")
        plt.close(fig)
