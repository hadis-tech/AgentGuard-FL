"""The experiment plan and the resumable runner.

Groups:

* main: AgentGuard-FL, FedAvg, Krum and Trimmed Mean x {no attack, CA-LFA, RLFA, ALIE}.
* models: FedRNN, FedCNN and FedLSTM x {CA-LFA, RLFA, ALIE}.
* ablation: AgentGuard-FL with one component removed, under CA-LFA and ALIE.
* backbone: random frozen BERT, BERT from scratch and MLP inside AgentGuard-FL.
* heterogeneity: IID and Dirichlet alpha in {1.0, 0.5, 0.1}.
* sensitivity: kappa_q, lambda_R, gamma_q and tau sweeps.
* forged: AgentGuard-FL when attackers forge their telemetry.

Attack rate: with ``rate_means="flip_ratio"``, 40% of clients are malicious and the rate is rho.
ALIE has no rho, so it runs once with 40% malicious clients (rate column = 0.40). With
``rate_means="malicious_frac"``, the rate is the fraction of malicious clients and rho is
``fixed_flip_ratio``.

Identical runs (for example the main AgentGuard-FL run and the alpha = 0.1 heterogeneity run) are
computed once and reused.
"""

import hashlib
import json
import os
from dataclasses import asdict, dataclass, field, replace
from typing import Dict, List, Tuple

import pandas as pd

from .config import Config
from .federation import run_experiment

MAIN_METHODS = [("AgentGuard-FL", "tinybert", "agentguard"), ("FedAvg", "tinybert", "fedavg"),
                ("Krum", "tinybert", "krum"), ("Trimmed Mean", "tinybert", "trimmed_mean")]
LF_ATTACKS = ["ca_lfa", "rlfa"]
HETEROGENEITY_SETTINGS = [("IID", dict(partition="iid")), ("alpha=1.0", dict(dirichlet_alpha=1.0)),
                          ("alpha=0.5", dict(dirichlet_alpha=0.5)), ("alpha=0.1", dict(dirichlet_alpha=0.1))]
LABELS = ["dataset", "group", "method", "setting", "model", "defence", "attack", "rate", "rho",
          "malicious_frac", "partition", "alpha", "seed", "run_id"]


@dataclass(frozen=True)
class ExperimentSettings:
    attack_rates: Tuple[float, ...] = (0.25, 0.35)
    rate_means: str = "flip_ratio"               # or "malicious_frac"
    fixed_flip_ratio: float = 1.0
    seeds: Tuple[int, ...] = (42, 43, 44)        # mean +/- std and 95% CI over seeds
    sweep_rate: float = 0.35                     # rate used by the heterogeneity and sensitivity sweeps
    # "all" = every dataset, "first" = first dataset only, False = skip
    run_groups: Dict[str, object] = field(default_factory=lambda: dict(
        main="all", models="all", ablation="all", backbone="all",
        heterogeneity="first", sensitivity="first", forged="all"))


def E(group, method, model, defence, attack, rate, setting="default", **overrides):
    return dict(group=group, method=method, model=model, defence=defence, attack=attack,
                rate=rate, setting=setting, overrides=overrides)


def alie_rates(cfg: Config, st: ExperimentSettings) -> List[float]:
    return [cfg.malicious_frac] if st.rate_means == "flip_ratio" else list(st.attack_rates)


def build_grid(cfg: Config, st: ExperimentSettings) -> List[dict]:
    g = []
    rates, alie = list(st.attack_rates), alie_rates(cfg, st)
    for m in MAIN_METHODS:
        g.append(E("main", *m, "none", 0.0))
        for r in rates:
            for a in LF_ATTACKS:
                g.append(E("main", *m, a, r))
        for r in alie:
            g.append(E("main", *m, "alie", r))

    for kind, name in [("rnn", "FedRNN"), ("cnn", "FedCNN"), ("lstm", "FedLSTM")]:
        for r in rates:
            for a in LF_ATTACKS:
                g.append(E("models", name, kind, "fedavg", a, r))
        for r in alie:
            g.append(E("models", name, kind, "fedavg", "alie", r))

    ablations = [("w/o reliability weighting", dict(use_reliability=False)),
                 ("w/o update clipping", dict(use_clipping=False)),
                 ("w/o client agent (reliability + clipping)", dict(use_reliability=False, use_clipping=False)),
                 ("w/o label trust T_lab", dict(use_T_lab=False)),
                 ("w/o validation trust T_val", dict(use_T_val=False)),
                 ("w/o magnitude trust T_mag", dict(use_T_mag=False)),
                 ("w/o direction trust T_dir", dict(use_T_dir=False)),
                 ("w/o reputation (λ_R = 0)", dict(lambda_R=0.0)),
                 ("w/o server trust (all T)", dict(use_trust=False))]
    for name, ov in [("AgentGuard-FL (full)", {})] + ablations:
        for r in rates:
            g.append(E("ablation", name, "tinybert", "agentguard", "ca_lfa", r, **ov))
        for r in alie:
            g.append(E("ablation", name, "tinybert", "agentguard", "alie", r, **ov))

    for name, kind, ov in [("Pretrained frozen BERT-Tiny (proposed)", "tinybert", {}),
                           ("Random frozen BERT-Tiny", "tinybert", dict(backbone_mode="random_frozen")),
                           ("BERT-Tiny trained from scratch", "tinybert", dict(backbone_mode="scratch_trainable")),
                           ("MLP", "mlp", {})]:
        g.append(E("backbone", name, kind, "agentguard", "none", 0.0, **ov))
        for r in rates:
            g.append(E("backbone", name, kind, "agentguard", "ca_lfa", r, **ov))

    for setting, ov in HETEROGENEITY_SETTINGS:
        for m in MAIN_METHODS:
            g.append(E("heterogeneity", *m, "none", 0.0, setting, **ov))
            g.append(E("heterogeneity", *m, "ca_lfa", st.sweep_rate, setting, **ov))

    for p, vals in [("kappa_q", [2.0, 4.0, 8.0, 16.0]), ("lambda_R", [0.0, 0.2, 0.5, 0.8]),
                    ("gamma_q", [0.2, 0.3, 0.4, 0.5]), ("tau", [0.5, 1.0, 2.0, 4.0])]:
        for v in vals:
            g.append(E("sensitivity", "AgentGuard-FL", "tinybert", "agentguard", "ca_lfa", st.sweep_rate,
                       f"{p}={v}", **{p: v}))

    for r in rates:
        g.append(E("forged", "AgentGuard-FL (forged telemetry)", "tinybert", "agentguard", "ca_lfa", r,
                   attacker_forges_telemetry=True))
    for r in alie:
        g.append(E("forged", "AgentGuard-FL (forged telemetry)", "tinybert", "agentguard", "alie", r,
                   attacker_forges_telemetry=True))
    return g


def exp_config(exp: dict, base: Config, st: ExperimentSettings) -> Config:
    """Return the Config for one experiment and set ``exp["rho"]``."""
    cfg = replace(base, **exp["overrides"])
    if exp["attack"] == "alie":
        exp["rho"] = 0.0
        if st.rate_means == "malicious_frac":
            cfg = replace(cfg, malicious_frac=exp["rate"])
    elif st.rate_means == "flip_ratio":
        exp["rho"] = exp["rate"]
    else:
        exp["rho"] = st.fixed_flip_ratio
        if exp["attack"] != "none":
            cfg = replace(cfg, malicious_frac=exp["rate"])
    return cfg


def run_id(ds_name: str, exp: dict, cfg: Config, seed: int) -> str:
    key = dict(ds=ds_name, model=exp["model"], defence=exp["defence"], attack=exp["attack"],
               rho=exp["rho"], seed=seed, cfg=asdict(cfg))
    return hashlib.md5(json.dumps(key, sort_keys=True, default=str).encode()).hexdigest()[:12]


def build_plan(datasets: List[dict], base: Config, st: ExperimentSettings) -> list:
    """Expand the grid into (dataset, experiment, config, seed, run_id) tuples."""
    def datasets_for(group):
        sel = st.run_groups.get(group, False)
        return [] if not sel else (datasets if sel == "all" else datasets[:1])

    grid = build_grid(base, st)
    plan = []
    for ds in datasets:
        for exp in grid:
            if not any(ds is d for d in datasets_for(exp["group"])):
                continue
            e = dict(exp)
            cfg = exp_config(e, base, st)
            for seed in st.seeds:
                plan.append((ds, e, cfg, seed, run_id(ds["name"], e, cfg, seed)))
    print(f"{len(plan)} planned runs, {len({p[4] for p in plan})} unique "
          f"(groups: {', '.join(k for k, v in st.run_groups.items() if v)})")
    return plan


def load_checkpoint(csv_path: str) -> pd.DataFrame:
    results = pd.read_csv(csv_path) if os.path.exists(csv_path) else pd.DataFrame()
    # A results file with different columns can't be resumed: keep it and start a fresh one.
    if not results.empty and not {"run_id", "group", "method", "setting"}.issubset(results.columns):
        old = csv_path.replace(".csv", "_old_format.csv")
        os.replace(csv_path, old)
        print(f"Old-format results moved to {old}; starting a new results file.")
        results = pd.DataFrame()
    return results


def cached_histories(results: pd.DataFrame) -> dict:
    """Per-run history from a checkpoint."""
    if results.empty:
        return {}
    return {rid: g.drop(columns=[c for c in LABELS if c in g.columns]).to_dict("records")
            for rid, g in results.groupby("run_id")}


def run_plan(plan: list, device: str, results_dir: str = "results") -> pd.DataFrame:
    """Run every planned experiment, checkpointing to ``all_rounds.csv`` after each one."""
    csv_path = os.path.join(results_dir, "all_rounds.csv")
    results = load_checkpoint(csv_path)
    done = set() if results.empty else set(zip(results["run_id"], results["group"], results["method"], results["setting"]))
    cache = cached_histories(results)
    new_rows = []
    for i, (ds, e, cfg, seed, rid) in enumerate(plan, 1):
        if (rid, e["group"], e["method"], e["setting"]) in done:
            continue
        if rid not in cache:
            print(f"[{i}/{len(plan)}]")
            cache[rid] = run_experiment(ds, e, cfg, seed, device)
        labels = dict(dataset=ds["name"], group=e["group"], method=e["method"], setting=e["setting"],
                      model=e["model"], defence=e["defence"], attack=e["attack"], rate=e["rate"], rho=e["rho"],
                      malicious_frac=cfg.malicious_frac, partition=cfg.partition, alpha=cfg.dirichlet_alpha,
                      seed=seed, run_id=rid)
        new_rows += [{**labels, **r} for r in cache[rid]]
        done.add((rid, e["group"], e["method"], e["setting"]))
        pd.concat([results, pd.DataFrame(new_rows)], ignore_index=True).to_csv(csv_path, index=False)
    return pd.concat([results, pd.DataFrame(new_rows)], ignore_index=True)


def save_run_config(path: str, base: Config, st: ExperimentSettings) -> None:
    with open(path, "w") as fh:
        fh.write(json.dumps(dict(config=asdict(base), ATTACK_RATES=list(st.attack_rates),
                                 ATTACK_RATE_MEANS=st.rate_means, SEEDS=list(st.seeds),
                                 RUN_GROUPS=st.run_groups), indent=1, default=str))
