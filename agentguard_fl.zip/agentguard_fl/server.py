"""Server aggregation.

AgentGuard-FL (Eqs. 34-42): the update norm in Eq. 36 is computed by the server from the received
update, which equals the reported norm when sigma = 0 and cannot be forged. Each trust term can be
switched off for the ablation study.

Krum (Blanchard et al. 2017): picks the single update with the smallest sum of squared distances to
its n - f - 2 nearest neighbours. It requires n > 2f + 2; with 4 of 10 attackers this fails, so f is
capped at floor((n - 3) / 2) = 3.

Trimmed Mean (Yin et al. 2018): per coordinate, drop the f largest and f smallest values and average
the rest (f capped at floor((n - 1) / 2)).

Note on non-IID data: an honest client holding mostly the class the global model currently gets
wrong has a high suspicion ratio mu and fails the sanity check, so it is down-weighted like an
attacker. Check the "AgentGuard-FL / No attack" row for each alpha in the heterogeneity table.
"""

import numpy as np
import torch

from .models import flat, unflat


class AgentGuardServer:
    def __init__(self, n_clients, cfg):
        self.cfg = cfg
        self.R = np.full(n_clients, cfg.R0, dtype=np.float64)

    def aggregate(self, theta_g, cids, deltas, teles, rnd=1):
        c = self.cfg
        use_trust = c.use_trust and rnd > c.defence_warmup_rounds
        U = torch.stack([flat(d) for d in deltas]).double()
        norms = U.norm(dim=1).numpy()                                            # server-side
        m_norm = float(np.median(norms))
        ref = U.median(dim=0).values                                             # reference update
        info = {}
        for i, cid in enumerate(cids):
            t = teles[i]
            T = 1.0
            if use_trust:
                if c.use_T_lab:
                    T *= np.exp(-c.kappa_q * t["mu"])                                            # Eq. 34
                if c.use_T_val:
                    T *= t["z"] * t["acc"] * np.exp(-c.kappa_l * t["loss"]) if np.isfinite(t["loss"]) else 0.0  # Eq. 35
                if c.use_T_mag:
                    T *= np.exp(-c.kappa_m * abs(norms[i] - m_norm) / (m_norm + c.eps)) * (1 - c.lambda_c * t["clip"])  # Eq. 36
                if c.use_T_dir:
                    d_i = float(U[i] @ ref / (U[i].norm() * ref.norm() + c.eps))                  # Eq. 37
                    T *= max(0.0, (1 + d_i) / 2)                                                  # Eq. 38
                self.R[cid] = c.lambda_R * self.R[cid] + (1 - c.lambda_R) * T                   # Eq. 40
            info[cid] = dict(T=T, R=self.R[cid], mu=t["mu"])
        raw = np.array([teles[i]["n"] ** c.size_power * self.R[cid] for i, cid in enumerate(cids)])
        if raw.sum() <= c.eps:
            return theta_g, info
        beta = torch.as_tensor(raw / (raw.sum() + c.eps))                       # Eq. 41
        return unflat(flat(theta_g).double() + (beta[:, None] * U).sum(0), theta_g), info  # Eq. 42


def robust_f(cfg):
    return cfg.robust_f if cfg.robust_f is not None else int(round(cfg.n_clients * cfg.malicious_frac))


def aggregate_baseline(theta_g, deltas, ns, method, cfg):
    U = torch.stack([flat(d) for d in deltas])
    M, f = U.shape[0], robust_f(cfg)
    if method == "fedavg":
        w = torch.as_tensor(np.asarray(ns, dtype=np.float64) / np.sum(ns), dtype=torch.float32)
        agg = (w[:, None] * U).sum(0)
    elif method == "trimmed_mean":
        k = min(f, (M - 1) // 2)
        agg = U.sort(dim=0).values[k:M - k].mean(0)
    elif method == "krum":
        f = min(f, max(0, (M - 3) // 2))
        D = torch.cdist(U, U) ** 2
        scores = torch.sort(D, dim=1).values[:, 1:M - f - 1].sum(1)
        agg = U[int(scores.argmin())]
    else:
        raise ValueError(method)
    return unflat(flat(theta_g) + agg, theta_g)
