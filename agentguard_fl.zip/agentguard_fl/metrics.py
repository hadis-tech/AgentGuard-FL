"""Metrics, all computed from one confusion matrix. Attack is the positive class.

Accuracy = (TP + TN) / N, Precision = TP / (TP + FP), Recall = TP / (TP + FN),
F1 = 2PR / (P + R), FPR = FP / (FP + TN). Binary definitions, no macro or weighted averaging.
"""

from .models import predict_logits


def confusion_counts(y_true, y_pred):
    return dict(tp=int(((y_pred == 1) & (y_true == 1)).sum()), tn=int(((y_pred == 0) & (y_true == 0)).sum()),
                fp=int(((y_pred == 1) & (y_true == 0)).sum()), fn=int(((y_pred == 0) & (y_true == 1)).sum()))


def metrics_from_counts(tp, tn, fp, fn):
    n = tp + tn + fp + fn
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn) if tp + fn else 0.0
    return dict(accuracy=100 * (tp + tn) / n, precision=100 * prec, recall=100 * rec,
                f1=100 * (2 * prec * rec / (prec + rec) if prec + rec else 0.0),
                fpr=100 * (fp / (fp + tn) if fp + tn else 0.0))


def evaluate(model, X, y, device):
    pred = predict_logits(model, X, device).argmax(1).numpy()
    cm = confusion_counts(y, pred)
    return {**metrics_from_counts(**cm), **cm}
