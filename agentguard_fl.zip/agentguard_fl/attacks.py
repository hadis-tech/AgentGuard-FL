"""Poisoning attacks.

* CA-LFA (Algorithm 1): the top-rho attack samples by global-model confidence are flipped to
  normal, recomputed each round; the poisoned update is projected to norm tau_a.
* RLFA: a random rho fraction of attack samples is flipped to normal (static poisoned dataset).
* ALIE (Baruch et al., NeurIPS 2019, "A Little Is Enough"): a model-poisoning attack that does not
  touch labels. Colluding attackers estimate the coordinate-wise mean mu and std sigma of benign
  updates and all submit mu - z * sigma, a shift small enough to hide inside normal client
  variation. z = Phi^-1((n - s) / n) with s = floor(n / 2 + 1) - f; for n = 10, f = 4 this gives
  z = 0.84. The update is crafted in ``federation.run_experiment``.
"""

import numpy as np
from scipy.stats import norm as _normal

from .models import flat

ATTACK_NAMES = {"none": "No attack", "ca_lfa": "CA-LFA", "rlfa": "RLFA", "alie": "ALIE"}


def calfa_flip(p_attack, y, rho):
    y_t = y.copy()
    att = np.where(y == 1)[0]
    if len(att) == 0 or rho <= 0:
        return y_t
    k = int(np.ceil(rho * len(att)))
    y_t[att[np.argsort(-p_attack[att], kind="stable")[:k]]] = 0      # Eqs. 3-5
    return y_t


def rlfa_flip(y, rho, rng, mode="attack_to_normal"):
    y_t = y.copy()
    pool = np.where(y == 1)[0] if mode == "attack_to_normal" else np.arange(len(y))
    if len(pool) == 0 or rho <= 0:
        return y_t
    chosen = rng.choice(pool, size=int(np.ceil(rho * len(pool))), replace=False)
    y_t[chosen] = 0 if mode == "attack_to_normal" else 1 - y_t[chosen]
    return y_t


def alie_z(n: int, f: int) -> float:
    s = n // 2 + 1 - f
    return float(_normal.ppf((n - max(s, 1)) / n))


def norm_project(delta, budget):
    n = flat(delta).norm().item()
    scale = min(1.0, budget / (n + 1e-12))
    return {k: v * scale for k, v in delta.items()}
