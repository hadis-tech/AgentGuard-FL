"""Local training and the AgentGuard-FL client agent (Algorithm 2, lines 2-16).

Threat model, the same for every defence: malicious clients control their own data and training.
Label-flipping attackers poison their labels (training and private validation part) and run
Algorithm 1; the ALIE attacker trains honestly and then submits a crafted update. They never run
the AgentGuard agent. By default they report telemetry computed honestly from their own data; with
``attacker_forges_telemetry=True`` they report perfect telemetry instead.
"""

import numpy as np
import torch
import torch.nn.functional as F

from .attacks import calfa_flip, norm_project
from .models import flat, get_trainable, predict_attack_proba, set_trainable, to_input, val_acc_loss


def local_train(model, X, y, cfg, device, epochs, lr, batch_size, rng,
                reliability=None, X_val=None, y_val=None, early_stop=False):
    """Class-weighted (Eq. 17), optionally reliability-weighted (Eq. 20) cross-entropy.

    Weighted mean (sum(w * l) / sum(w)): relative sample weights are exactly those of Eqs. 17/20.
    """
    n = len(y)
    if n == 0:
        return
    w = (n / np.maximum(1, np.bincount(y, minlength=2)))[y]
    if reliability is not None:
        w = w * reliability
    w_t, y_t = torch.as_tensor(w, dtype=torch.float32), torch.as_tensor(y)
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.Adam(params, lr=lr)
    prev_loss, worse = float("inf"), 0
    for _ in range(epochs):
        model.train()
        perm = rng.permutation(n)
        for s in range(0, n, batch_size):
            idx = perm[s:s + batch_size]
            xb = to_input(X[idx], model, device)
            yb, wb = y_t[idx].to(device), w_t[idx].to(device)
            loss = (F.cross_entropy(model(xb), yb, reduction="none") * wb).sum() / (wb.sum() + 1e-12)
            opt.zero_grad()
            loss.backward()
            if cfg.grad_clip_norm > 0:
                torch.nn.utils.clip_grad_norm_(params, cfg.grad_clip_norm)
            opt.step()
        if early_stop and y_val is not None and len(y_val) > 0:               # Eq. 27
            _, vl = val_acc_loss(model, X_val, y_val, device)
            worse = worse + 1 if vl > prev_loss else 0
            prev_loss = vl
            if worse >= 2:
                for g in opt.param_groups:
                    g["lr"] *= 0.5
                break


def client_round(model, theta_g, X_tr, y_tr, X_va, y_va, *, defence, is_mal, attack, rho,
                 rlfa_labels, cfg, device, rng, rnd=1):
    """One client, one round. Returns (update, telemetry, n_i, n_flipped).

    ALIE attackers train honestly here; their crafted update is substituted in run_experiment.
    """
    set_trainable(model, theta_g)
    y_tr0 = y_tr

    # (1) Label poisoning (Algorithm 1, lines 1-4)
    p_tr = None
    if is_mal and attack == "ca_lfa":
        p_tr = predict_attack_proba(model, X_tr, device)
        y_tr = calfa_flip(p_tr, y_tr, rho)
        y_va = calfa_flip(predict_attack_proba(model, X_va, device), y_va, rho)
    elif is_mal and attack == "rlfa":
        y_tr, y_va = rlfa_labels
    n_flipped = int((y_tr != y_tr0).sum())

    runs_agent = defence == "agentguard" and (not is_mal or cfg.attacker_runs_agent)
    if runs_agent:                                           # pre-flight validation
        ok = np.isin(y_tr, [0, 1])
        X_tr, y_tr = X_tr[ok], y_tr[ok]
        p_tr = p_tr[ok] if p_tr is not None else None
    n = len(y_tr)
    if n == 0:
        zero = {k: torch.zeros_like(v) for k, v in theta_g.items()}
        return zero, dict(n=0, acc=0.0, loss=float("inf"), clip=0, z=0, mu=1.0), 0, n_flipped

    # (2) Label consistency (Eqs. 18, 19, 21)
    mu, rel = 0.0, None
    if defence == "agentguard":
        if p_tr is None:
            p_tr = predict_attack_proba(model, X_tr, device)
        q = np.abs(y_tr - p_tr)
        mu = float(np.mean(q >= cfg.gamma_q))
        if runs_agent and cfg.use_reliability and rnd > cfg.defence_warmup_rounds:
            rel = np.maximum(cfg.r_min, 1.0 - q)

    # (3) Local training
    if runs_agent:
        full = n >= cfg.light_plan_min_samples
        epochs, bs = (cfg.local_epochs, cfg.batch_size) if full else (1, min(cfg.batch_size, cfg.batch_min))
        local_train(model, X_tr, y_tr, cfg, device, epochs, cfg.lr, bs, rng,
                    reliability=rel, X_val=X_va, y_val=y_va, early_stop=True)
    else:
        local_train(model, X_tr, y_tr, cfg, device, cfg.local_epochs, cfg.lr, cfg.batch_size, rng)

    theta_local = get_trainable(model)
    delta = {k: theta_local[k] - theta_g[k] for k in theta_g}
    raw_norm = flat(delta).norm().item()

    # (4) Post-processing
    if runs_agent:
        clip_flag = int(raw_norm > cfg.tau)                                      # Eq. 31
        if cfg.use_clipping:
            delta = norm_project(delta, cfg.tau)                                 # Eq. 29
        if cfg.sigma > 0:
            delta = {k: v + torch.randn_like(v) * cfg.sigma for k, v in delta.items()}  # Eq. 30
    else:
        if is_mal and attack == "ca_lfa" and cfg.calfa_norm_projection:
            delta = norm_project(delta, cfg.tau_a)                               # Eq. 9
        clip_flag = int(flat(delta).norm().item() > cfg.tau)

    # (5) Telemetry (Eqs. 32-33)
    tele = None
    if defence == "agentguard":
        acc, loss = val_acc_loss(model, X_va, y_va, device)
        tele = dict(n=n, acc=acc, loss=loss, clip=clip_flag,
                    z=int(acc >= cfg.gamma_acc and loss <= cfg.gamma_loss), mu=mu)
    return delta, tele, n, n_flipped
