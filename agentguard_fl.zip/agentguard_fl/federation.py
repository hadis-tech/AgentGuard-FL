"""Client partitioning, data-distribution reports and the federated training loop."""

import os
import time

import numpy as np
import pandas as pd
import torch

from .attacks import ATTACK_NAMES, alie_z, rlfa_flip
from .client import client_round
from .config import set_seed
from .metrics import evaluate
from .models import flat, get_trainable, make_model, set_trainable, unflat
from .server import AgentGuardServer, aggregate_baseline


def partition_indices(y, cfg, rng, min_size=None):
    n, N = len(y), cfg.n_clients
    if cfg.partition == "iid":
        return [np.sort(s) for s in np.array_split(rng.permutation(n), N)]
    if min_size is None:           # 20 samples for large datasets, smaller for small ones
        min_size = max(2, min(20, n // (20 * N)))
    for required in (min_size, max(1, min_size // 2), 1):   # relax the minimum if needed
        for _ in range(5000):
            parts = [[] for _ in range(N)]
            for c in np.unique(y):
                idx = rng.permutation(np.where(y == c)[0])
                props = rng.dirichlet(np.repeat(cfg.dirichlet_alpha, N))
                for i, chunk in enumerate(np.split(idx, (np.cumsum(props) * len(idx)).astype(int)[:-1])):
                    parts[i].extend(chunk.tolist())
            if min(len(p) for p in parts) >= required:
                if required < min_size:
                    print(f"  note: Dirichlet partition uses a minimum of {required} samples per client")
                return [np.array(sorted(p)) for p in parts]
    raise RuntimeError("Could not draw a Dirichlet partition with non-empty clients; increase alpha.")


def make_clients(y_train, cfg, seed, attack):
    """Same seed -> same partition, local splits and malicious set (used by the run and the report)."""
    rng = np.random.default_rng(seed)
    parts = partition_indices(y_train, cfg, rng)
    splits = []
    for p in parts:
        p = rng.permutation(p)
        n_val = max(1, int(round(cfg.client_val_frac * len(p))))
        splits.append((p[n_val:], p[:n_val]))
    n_mal = int(round(cfg.n_clients * cfg.malicious_frac)) if attack != "none" else 0
    if n_mal == 0:
        mal = set()
    elif cfg.malicious_selection == "random":
        mal = set(rng.choice(cfg.n_clients, n_mal, replace=False).tolist())
    else:
        counts = np.array([int((y_train[tr] == 1).sum()) for tr, _ in splits])
        mal = set(np.argsort(-counts, kind="stable")[:n_mal].tolist())
    return splits, mal, rng


def describe_clients(ds, cfg, seed, setting, results_dir="results", attack="ca_lfa"):
    """Per-client sample and class counts plus one heterogeneity number.

    Heterogeneity = mean total-variation distance between each client's class distribution and
    the global one (0 = IID, 0.5 = maximally skewed for a balanced binary problem).
    """
    y = ds["y_train"]
    splits, mal, _ = make_clients(y, cfg, seed, attack)
    g = np.array([np.mean(y == 0), np.mean(y == 1)])
    rows = []
    for cid, (tr, va) in enumerate(splits):
        yy = y[np.concatenate([tr, va])]
        p = np.array([np.mean(yy == 0), np.mean(yy == 1)])
        rows.append(dict(client=cid, n=len(yy), normal=int((yy == 0).sum()), attack=int((yy == 1).sum()),
                         attack_ratio=round(float(p[1]), 4), malicious=cid in mal,
                         tv_distance=round(float(0.5 * np.abs(p - g).sum()), 4)))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(results_dir, f"client_distribution_{ds['name']}_{setting}_seed{seed}.csv"), index=False)
    return df, float(df["tv_distance"].mean())


def run_experiment(ds, exp, cfg, seed, device, verbose=True):
    """Run one federated experiment and return one history row per communication round."""
    set_seed(seed)
    kind, defence, attack, rho = exp["model"], exp["defence"], exp["attack"], exp["rho"]
    Xs = "T" if kind == "tinybert" else "X"
    X_train, X_test = ds[f"{Xs}_train"], ds[f"{Xs}_test"]
    y_train, y_test = ds["y_train"], ds["y_test"]
    splits, mal, rng = make_clients(y_train, cfg, seed, attack)
    n_mal = len(mal)

    rlfa_cache = {}
    if attack == "rlfa":
        for cid in sorted(mal):
            tr, va = splits[cid]
            rlfa_cache[cid] = (rlfa_flip(y_train[tr], rho, rng, cfg.rlfa_mode),
                               rlfa_flip(y_train[va], rho, rng, cfg.rlfa_mode))

    model = make_model(kind, ds["n_features"], cfg, device)
    theta = get_trainable(model)
    server = AgentGuardServer(cfg.n_clients, cfg) if defence == "agentguard" else None
    z_alie = cfg.alie_z if cfg.alie_z is not None else alie_z(cfg.n_clients, n_mal)
    if verbose:
        print(f"  {ds['name']} | {exp['group']} | {exp['method']} | {ATTACK_NAMES[attack]} rate={exp['rate']} "
              f"[{exp['setting']}] seed={seed} | malicious={sorted(mal)} | params={flat(theta).numel():,}")

    history, t0 = [], time.time()
    for rnd in range(1, cfg.n_rounds + 1):
        active = attack if rnd > cfg.warmup_rounds else "none"
        deltas, teles, ns, flips = [], [], [], 0
        for cid, (tr, va) in enumerate(splits):
            d, t, n_i, nf = client_round(
                model, theta, X_train[tr], y_train[tr], X_train[va], y_train[va],
                defence=defence, is_mal=(cid in mal and active != "none"), attack=active, rho=rho,
                rlfa_labels=rlfa_cache.get(cid), cfg=cfg, device=device, rng=rng, rnd=rnd)
            deltas.append(d)
            teles.append(t)
            ns.append(n_i)
            flips += nf

        if active == "alie" and mal:                          # ALIE: replace the attackers' updates
            src = sorted(mal) if cfg.alie_knowledge == "partial" else [i for i in range(cfg.n_clients) if i not in mal]
            S = torch.stack([flat(deltas[i]) for i in src])
            sd = S.std(dim=0) if len(src) > 1 else torch.zeros_like(S[0])
            crafted = unflat(S.mean(dim=0) - z_alie * sd, theta)
            for i in mal:
                deltas[i] = {k: v.clone() for k, v in crafted.items()}
                if teles[i] is not None:
                    teles[i]["clip"] = int(flat(crafted).norm().item() > cfg.tau)

        if defence == "agentguard" and cfg.attacker_forges_telemetry and active != "none":
            for i in mal:                                     # attacker reports perfect telemetry
                teles[i].update(acc=1.0, loss=0.01, z=1, clip=0, mu=0.0)

        info = {}
        if defence == "agentguard":
            theta, info = server.aggregate(theta, list(range(cfg.n_clients)), deltas, teles, rnd=rnd)
        else:
            theta = aggregate_baseline(theta, deltas, ns, defence, cfg)
        set_trainable(model, theta)
        m = evaluate(model, X_test, y_test, device)

        def _mean(key, group):
            v = [info[c][key] for c in info if (c in mal) == group]
            return float(np.mean(v)) if v else np.nan

        history.append(dict(round=rnd, n_malicious=n_mal, n_flipped=flips,
                            trust_mal=_mean("T", True), trust_ben=_mean("T", False),
                            rep_mal=_mean("R", True), rep_ben=_mean("R", False),
                            mu_mal=_mean("mu", True), mu_ben=_mean("mu", False), **m))
        if verbose and (rnd == 1 or rnd % 10 == 0 or rnd == cfg.n_rounds):
            print(f"    round {rnd:>3}: acc={m['accuracy']:.2f} P={m['precision']:.2f} R={m['recall']:.2f} "
                  f"F1={m['f1']:.2f} FPR={m['fpr']:.2f} | TP={m['tp']} FN={m['fn']} FP={m['fp']} TN={m['tn']}")
    if verbose:
        print(f"    done in {time.time() - t0:.0f}s")
    return history
