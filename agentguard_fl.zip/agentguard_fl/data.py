"""Dataset loading, splitting, scaling and quantile tokenisation (Eq. 14).

Labels are binary (0 = normal, 1 = attack). Timestamp, address and label-derived columns are
dropped, because CICIoV2024's ``category`` and ``specific_class`` would otherwise leak the label.
Large datasets are sampled chunk by chunk, then capped at ``max_rows`` with stratification.
"""

import os
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from .config import Config

# Sampling settings per dataset. Paths are supplied on the command line.
DATASET_SPECS = {
    "N-BaIoT": dict(sample_frac=0.02, max_rows=100_000, infer_label_from_path=True),
    "CSE-CIC-IDS2018": dict(sample_frac=0.02, max_rows=100_000),
    "CICIoV2024": dict(sample_frac=1.0, max_rows=100_000),
}
DATA_SPLIT_SEED = 42  # fixed train/val/test split, so every run is scored on the same test set

NORMAL_LABELS = {"benign", "normal", "0"}
DROP_COLUMNS = {
    "timestamp", "flow id", "src ip", "dst ip", "src port", "source ip", "destination ip",
    "source port", "category", "specific_class", "attack", "attack_type", "class",
}


def _csv_files(path: str) -> List[str]:
    if os.path.isfile(path) and path.lower().endswith(".csv"):
        return [path]
    files = []
    if os.path.isdir(path):
        for root, _, names in os.walk(path):
            files += [os.path.join(root, n) for n in sorted(names) if n.lower().endswith(".csv")]
    return files


def _read_csv_sampled(fp: str, frac: float, seed: int, chunksize: int = 250_000) -> pd.DataFrame:
    kw = dict(low_memory=False, encoding="latin-1")
    if frac >= 1.0:
        return pd.read_csv(fp, **kw)
    parts = [chunk.sample(frac=frac, random_state=seed + i)
             for i, chunk in enumerate(pd.read_csv(fp, chunksize=chunksize, **kw))]
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def load_ids_dataset(name: str, path: str, sample_frac: float = 1.0, max_rows: Optional[int] = None,
                     infer_label_from_path: bool = False,
                     seed: int = DATA_SPLIT_SEED) -> Tuple[np.ndarray, np.ndarray]:
    """Load every CSV under ``path`` and return ``(X, y)`` after cleaning and de-duplication."""
    files = _csv_files(path)
    if not files:
        raise FileNotFoundError(f"[{name}] no CSV files under '{path}'.")
    frames = []
    for fp in files:
        df = _read_csv_sampled(fp, sample_frac, seed)
        if df.empty:
            continue
        df.columns = [str(c).strip() for c in df.columns]
        label_col = next((c for c in df.columns if c.lower() == "label"), None)
        if label_col is None:
            if not infer_label_from_path:
                raise ValueError(f"[{name}] {fp} has no 'label' column.")
            df["label"] = 0 if "benign" in os.path.relpath(fp, path).lower() else 1
        else:
            raw = df[label_col].astype(str).str.strip().str.lower()
            keep = raw != "label"                                   # repeated header rows
            df, raw = df[keep], raw[keep]
            num = pd.to_numeric(raw, errors="coerce")
            y = np.where(num.notna(), (num.fillna(0) != 0).astype(int), (~raw.isin(NORMAL_LABELS)).astype(int))
            df = df.drop(columns=[label_col])
            df["label"] = y
        frames.append(df)

    df = pd.concat(frames, ignore_index=True, sort=False)
    df = df.drop(columns=[c for c in df.columns if c.lower() in DROP_COLUMNS])
    y = df.pop("label").astype(int)
    X = df.apply(pd.to_numeric, errors="coerce")
    X = X.loc[:, X.notna().mean() > 0.5]
    X = X.replace([np.inf, -np.inf], np.nan)
    ok = X.notna().all(axis=1)
    X, y = X[ok], y[ok]
    full = X.assign(label=y.values).drop_duplicates()
    if max_rows and len(full) > max_rows:
        full, _ = train_test_split(full, train_size=max_rows, stratify=full["label"], random_state=seed)
    y = full.pop("label").to_numpy(np.int64)
    X = full.to_numpy(np.float32)
    print(f"[{name}] rows={len(y):,} features={X.shape[1]} attack_ratio={y.mean():.3f}")
    return X, y


def synthetic_dataset(n_rows: int, n_features: int, seed: int) -> Tuple[np.ndarray, np.ndarray]:
    """Fake data for checking that the pipeline runs. Never report results from it."""
    rng = np.random.default_rng(seed)
    y = rng.integers(0, 2, n_rows).astype(np.int64)
    X = rng.standard_normal((n_rows, n_features)).astype(np.float32)
    X[:, :10] += y[:, None] * 1.5
    return X, y


class QuantileTokenizer:
    """Maps each standardised feature value to one of B quantile bins (Eq. 14)."""

    def __init__(self, n_bins: int = 32):
        self.n_bins = n_bins
        self.edges = None

    def fit(self, X: np.ndarray) -> "QuantileTokenizer":
        qs = np.linspace(0, 1, self.n_bins + 1)[1:-1]
        self.edges = np.quantile(X, qs, axis=0).T
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        out = np.empty(X.shape, dtype=np.uint8)
        for k in range(X.shape[1]):
            out[:, k] = np.searchsorted(self.edges[k], X[:, k], side="right")
        return out


def prepare_dataset(name: str, X: np.ndarray, y: np.ndarray, cfg: Config, seed: int = DATA_SPLIT_SEED) -> dict:
    """70/15/15 stratified split; scaler and bin edges are fitted on training data only."""
    X_tr, X_tmp, y_tr, y_tmp = train_test_split(X, y, test_size=0.30, stratify=y, random_state=seed)
    X_va, X_te, y_va, y_te = train_test_split(X_tmp, y_tmp, test_size=0.50, stratify=y_tmp, random_state=seed)
    keep = X_tr.std(axis=0) > 0
    X_tr, X_va, X_te = X_tr[:, keep], X_va[:, keep], X_te[:, keep]
    scaler = StandardScaler().fit(X_tr)
    X_tr, X_va, X_te = (scaler.transform(a).astype(np.float32) for a in (X_tr, X_va, X_te))
    tok = QuantileTokenizer(cfg.n_bins).fit(X_tr)
    ds = dict(name=name, n_features=X_tr.shape[1],
              X_train=X_tr, X_val=X_va, X_test=X_te,
              T_train=tok.transform(X_tr), T_val=tok.transform(X_va), T_test=tok.transform(X_te),
              y_train=y_tr, y_val=y_va, y_test=y_te)
    print(f"[{name}] d={ds['n_features']} train={len(y_tr):,} val={len(y_va):,} test={len(y_te):,} "
          f"(test: {int((y_te == 1).sum()):,} attack / {int((y_te == 0).sum()):,} normal)")
    return ds


def save_class_distribution(datasets: List[dict], path: str) -> None:
    """Save class counts per split. Every row of every table uses the same test set."""
    pd.DataFrame([dict(dataset=d["name"], split=s, attack=int((d[f"y_{s}"] == 1).sum()),
                       normal=int((d[f"y_{s}"] == 0).sum()), total=len(d[f"y_{s}"]))
                  for d in datasets for s in ("train", "val", "test")]
                 ).to_csv(path, index=False)
