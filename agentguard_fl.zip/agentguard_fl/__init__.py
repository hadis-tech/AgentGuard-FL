"""AgentGuard-FL: robust agentic federated intrusion detection."""

__version__ = "1.0.0"
