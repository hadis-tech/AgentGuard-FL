"""Models and helpers for moving parameters and predictions around.

AgentGuard model: pseudo-tokens -> shared trainable embedding W_emb (+ bias) -> m soft prompts
prepended (Eq. 16) -> BERT-Tiny encoder -> mean pooling -> classifier W_last. The encoder's own
position embeddings tell it which feature each token is. ``Config.backbone_mode`` selects:

* ``pretrained_frozen``: the paper's design; only W_emb, b_emb, S and W_last are trained and sent.
* ``random_frozen``: same architecture, random frozen encoder (does pretraining matter?).
* ``scratch_trainable``: same architecture trained from scratch, encoder sent every round.

Other models: ``mlp`` (a plain MLP on the standardised features, usable with any defence) and the
sequence baselines ``cnn`` / ``rnn`` / ``lstm``, which read the feature vector as a sequence.
"""

from typing import Dict, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import BertConfig, BertModel

from .config import Config


class AgentGuardTinyBERT(nn.Module):
    input_kind = "tokens"

    def __init__(self, n_features: int, cfg: Config):
        super().__init__()
        if cfg.backbone_mode == "pretrained_frozen":
            self.encoder = BertModel.from_pretrained(cfg.backbone_name, add_pooling_layer=False)
        elif cfg.backbone_mode in ("random_frozen", "scratch_trainable"):
            # vocab_size=2: the word-embedding table is never used (we pass inputs_embeds)
            self.encoder = BertModel(BertConfig(vocab_size=2, hidden_size=128, num_hidden_layers=2,
                                                num_attention_heads=2, intermediate_size=512,
                                                max_position_embeddings=512), add_pooling_layer=False)
        else:
            raise ValueError(cfg.backbone_mode)
        d_model = self.encoder.config.hidden_size
        if cfg.n_prompts + n_features > self.encoder.config.max_position_embeddings:
            raise ValueError("n_prompts + n_features exceeds the backbone's maximum sequence length.")
        trainable_encoder = cfg.backbone_mode == "scratch_trainable"
        for name, p in self.encoder.named_parameters():
            p.requires_grad_(trainable_encoder and "word_embeddings" not in name)

        self.feature_embedding = nn.Embedding(cfg.n_bins, d_model)   # W_emb (Eq. 15)
        self.feature_bias = nn.Parameter(torch.zeros(d_model))       # b_emb
        nn.init.normal_(self.feature_embedding.weight, std=0.02)
        self.soft_prompts = nn.Parameter(torch.randn(cfg.n_prompts, d_model) * 0.02)  # S
        self.classifier = nn.Linear(d_model, 2)                      # W_last

    def train(self, mode: bool = True):
        super().train(mode)
        self.encoder.eval()            # no dropout in the encoder in any mode
        return self

    def forward(self, tokens):
        e = self.feature_embedding(tokens) + self.feature_bias
        s = self.soft_prompts.unsqueeze(0).expand(tokens.size(0), -1, -1)
        h = self.encoder(inputs_embeds=torch.cat([s, e], dim=1)).last_hidden_state
        return self.classifier(h.mean(dim=1))


class MLP(nn.Module):
    input_kind = "float"

    def __init__(self, n_features: int, hidden: int = 128):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(n_features, hidden), nn.ReLU(),
                                 nn.Linear(hidden, hidden), nn.ReLU(), nn.Linear(hidden, 2))

    def forward(self, x):
        return self.net(x)


class SeqBaseline(nn.Module):
    input_kind = "float"

    def __init__(self, n_features: int, kind: str, hidden: int = 64):
        super().__init__()
        self.kind = kind
        if kind == "cnn":
            self.body = nn.Sequential(nn.Conv1d(1, 32, 5, padding=2), nn.ReLU(),
                                      nn.Conv1d(32, 64, 5, padding=2), nn.ReLU(),
                                      nn.AdaptiveMaxPool1d(1), nn.Flatten())
            out = 64
        else:
            self.body = (nn.RNN if kind == "rnn" else nn.LSTM)(1, hidden, batch_first=True)
            out = hidden
        self.head = nn.Linear(out, 2)

    def forward(self, x):
        if self.kind == "cnn":
            return self.head(self.body(x.unsqueeze(1)))
        out, _ = self.body(x.unsqueeze(-1))
        return self.head(out[:, -1])


def make_model(kind: str, n_features: int, cfg: Config, device: str) -> nn.Module:
    if kind == "tinybert":
        m = AgentGuardTinyBERT(n_features, cfg)
    elif kind == "mlp":
        m = MLP(n_features)
    else:
        m = SeqBaseline(n_features, kind)
    return m.to(device)


def get_trainable(model: nn.Module) -> Dict[str, torch.Tensor]:
    return {n: p.detach().cpu().clone() for n, p in model.named_parameters() if p.requires_grad}


def set_trainable(model: nn.Module, state: Dict[str, torch.Tensor]) -> None:
    with torch.no_grad():
        for n, p in model.named_parameters():
            if n in state:
                p.copy_(state[n].to(p.device))


def flat(d: Dict[str, torch.Tensor]) -> torch.Tensor:
    return torch.cat([v.flatten() for v in d.values()])


def unflat(vec: torch.Tensor, like: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
    out, i = {}, 0
    for k, v in like.items():
        out[k] = vec[i:i + v.numel()].view_as(v).clone().to(v.dtype)
        i += v.numel()
    return out


def to_input(X: np.ndarray, model: nn.Module, device: str) -> torch.Tensor:
    if model.input_kind == "tokens":
        return torch.as_tensor(X.astype(np.int64), device=device)
    return torch.as_tensor(X, dtype=torch.float32, device=device)


@torch.no_grad()
def predict_logits(model: nn.Module, X: np.ndarray, device: str, bs: int = 2048) -> torch.Tensor:
    model.eval()
    out = [model(to_input(X[s:s + bs], model, device)).float().cpu() for s in range(0, len(X), bs)]
    return torch.cat(out) if out else torch.zeros(0, 2)


def predict_attack_proba(model: nn.Module, X: np.ndarray, device: str) -> np.ndarray:
    return F.softmax(predict_logits(model, X, device), dim=1)[:, 1].numpy()


def val_acc_loss(model: nn.Module, X: np.ndarray, y: np.ndarray, device: str) -> Tuple[float, float]:
    if len(y) == 0:
        return 0.0, float("inf")
    logits = predict_logits(model, X, device)
    return float((logits.argmax(1).numpy() == y).mean()), F.cross_entropy(logits, torch.as_tensor(y)).item()
